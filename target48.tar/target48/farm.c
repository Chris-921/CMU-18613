/*
 * Note: To get instruction addresses, DO NOT compile this file yourself.
 * Instead, you should disassemble the existing rtarget binary.
 */

/* This function marks the start of the farm */
int start_farm(void)
{
    return 1;
}

unsigned getval_181(void)
{
    return 2428995912U;
}

void setval_210(unsigned *p)
{
    *p = 3251079496U;
}

unsigned addval_493(unsigned x)
{
    return x + 2425641027U;
}

void setval_394(unsigned *p)
{
    *p = 2425379035U;
}

unsigned addval_233(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_397(unsigned x)
{
    return x + 3347663100U;
}

unsigned addval_311(unsigned x)
{
    return x + 3281096792U;
}

void setval_198(unsigned *p)
{
    *p = 3281017020U;
}

/* This function marks the middle of the farm */
int mid_farm(void)
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_154(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_168(unsigned x)
{
    return x + 3767355467U;
}

unsigned getval_201(void)
{
    return 3465129581U;
}

void setval_276(unsigned *p)
{
    *p = 2425474697U;
}

unsigned addval_316(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_398(void)
{
    return 3269495112U;
}

unsigned addval_100(unsigned x)
{
    return x + 3677929993U;
}

unsigned getval_383(void)
{
    return 482853513U;
}

unsigned getval_455(void)
{
    return 3281109641U;
}

unsigned addval_322(unsigned x)
{
    return x + 3376991881U;
}

unsigned addval_118(unsigned x)
{
    return x + 2425409033U;
}

unsigned addval_172(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_357(void)
{
    return 3286272328U;
}

unsigned getval_329(void)
{
    return 2425541001U;
}

void setval_370(unsigned *p)
{
    *p = 2446231860U;
}

void setval_182(unsigned *p)
{
    *p = 3281109641U;
}

unsigned getval_186(void)
{
    return 1539555977U;
}

unsigned addval_498(unsigned x)
{
    return x + 3517578127U;
}

void setval_122(unsigned *p)
{
    *p = 3523265161U;
}

unsigned getval_273(void)
{
    return 3221279113U;
}

unsigned addval_144(unsigned x)
{
    return x + 3286272840U;
}

void setval_497(unsigned *p)
{
    *p = 3380924809U;
}

unsigned getval_429(void)
{
    return 935842185U;
}

void setval_231(unsigned *p)
{
    *p = 3769190435U;
}

unsigned getval_200(void)
{
    return 3682913929U;
}

unsigned addval_367(unsigned x)
{
    return x + 3281047961U;
}

void setval_345(unsigned *p)
{
    *p = 3374370445U;
}

void setval_468(unsigned *p)
{
    *p = 3677933833U;
}

unsigned addval_174(unsigned x)
{
    return x + 3353381192U;
}

void setval_230(unsigned *p)
{
    *p = 2428668353U;
}

void setval_315(unsigned *p)
{
    *p = 2463009041U;
}

unsigned addval_388(unsigned x)
{
    return x + 3372794521U;
}

/* This function marks the end of the farm */
int end_farm(void)
{
    return 1;
}
